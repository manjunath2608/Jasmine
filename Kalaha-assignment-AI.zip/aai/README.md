# Applied Artificial Intelligence 

Kalaha Assignment
DV2557 - Blekinge Tekniska Hogskola


